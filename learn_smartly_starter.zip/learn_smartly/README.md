# Learn Smartly — starter website

## Open the prototype
Open `index.html` in a browser. It is a responsive, clickable front-end prototype.

## Included
- Learn Smartly landing page
- Class 10, 11 and 12 navigation
- Subject selector placeholder
- NDA Maths, NDA GAT, MH-CET PCM and PCB sections
- Mock-test planning cards
- AI tutor chat interface (demo response only)
- Mobile-friendly layout and search

## Important next steps
1. Confirm the current Maharashtra State Board syllabus and add chapter-wise notes.
2. Add original practice questions and properly sourced/licensed past-paper questions.
3. Implement quiz scoring, timers, answer explanations and progress tracking.
4. Build a backend and connect an AI provider securely. Never expose API keys in browser JavaScript.
5. Add authentication and payment integration only after the free learning experience is tested.
6. Have an adult/qualified developer review privacy, payments and student-data handling before launch.

The current file is a front-end starter, not a production-ready platform. It does not contain the full syllabus, actual 10-year PYQ bank, real ChatGPT integration, login or payment processing.
