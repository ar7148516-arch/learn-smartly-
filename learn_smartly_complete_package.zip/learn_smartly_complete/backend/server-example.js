// Example Node.js backend. Deploy on a trusted server; do not upload secrets.
import express from "express";
import cors from "cors";

const app = express();
app.use(express.json({ limit: "20kb" }));
// Set FRONTEND_ORIGIN to your exact GitHub Pages origin in production.
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || true }));

app.post("/api/ask", async (req, res) => {
  try {
    const { question, language = "Auto", level = "Very simple" } = req.body || {};
    if (typeof question !== "string" || !question.trim() || question.length > 4000) {
      return res.status(400).json({ error: "Please send a valid study question." });
    }
    if (!process.env.AI_API_KEY) {
      return res.status(503).json({ error: "AI service is not configured." });
    }

    // Connect your chosen AI provider here using its official server-side SDK/API.
    // Keep the provider key in AI_API_KEY environment variable only.
    // Prompt requirements: age-appropriate tutoring; explain rather than just give
    // answers; use requested language; do not claim generated practice is an official PYQ.
    return res.status(501).json({
      error: "Choose an AI provider and implement its official server-side SDK call.",
      requestedLanguage: language,
      requestedLevel: level
    });
  } catch (error) {
    console.error("Tutor error:", error);
    return res.status(500).json({ error: "Tutor temporarily unavailable." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Learn Smartly backend listening on ${port}`));
