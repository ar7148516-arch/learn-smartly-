# Learn Smartly — content and launch guide

## 1. Recommended platform name
**Learn Smartly**  
Tagline: **Learn simply. Grow confidently.**  
Alternative names: StudySaathi, SmartPath Learning, ExamBridge.

## 2. Sections already scaffolded in index.html
- Home dashboard
- Maharashtra Board: Classes 10, 11, 12
- Class 10 subject tiles: Mathematics, Science & Technology, English, Marathi, History & Political Science, Geography
- Classes 11 and 12 subject tiles: Physics, Chemistry, Biology, Mathematics, English, Marathi
- NDA Mathematics and GAT topic areas
- MH-CET PCM and PCB areas
- AI Tutor interface with Hindi, English, Marathi and explanation-level selectors
- Practice/mock test page with an original demo quiz
- Premium plan placeholder (not connected to payments)

## 3. Content record structure
Use `data/content-template.json` as the model. Each chapter should include:
- board/exam, class, subject, chapter number and title
- learning objectives and simple explanation
- key terms/formulas
- worked examples
- original easy/medium/hard questions with answer explanations
- PYQs only when the question is accurately traced to an official/authorized paper and year/session
- chapter test and answer key

## 4. Syllabus and PYQ integrity
Do not label generated practice questions as PYQs. Verify the current Maharashtra State Board syllabus and exam pattern before writing chapter lists. Use official or otherwise authorized past-paper sources; preserve exam, year, session and subject metadata. Check copyright and permissions before republishing complete question papers or large question collections. If permission is not available, link to the authorized source and write original practice questions instead.

## 5. Mock-test targets requested
- NDA Mathematics: target 120 questions / 300 marks
- NDA GAT: target 150 questions / 600 marks
- MH-CET: separate PCM and PCB test modes
Before launch, verify the current official exam pattern, section distribution, time limit, marking and negative-marking rules. The requested formats are stored as product targets, not guaranteed current official patterns.

## 6. AI Tutor activation
The included `backend/server-example.js` is a minimal server-side example. Deploy it to a backend host that supports Node.js, set `AI_API_KEY` as a private environment variable, and change the endpoint URL in `index.html` to your deployed backend URL. Add rate limits, abuse protection, age-appropriate safety, privacy notice and error handling. Never expose API keys in browser code or a public repository.

## 7. Premium
Premium is only a UI placeholder. Before accepting payments, have a parent/guardian or qualified adult review the payment provider's age/eligibility rules, business requirements, refund policy, tax obligations and student-data privacy. Do not store card, UPI PIN, passwords or sensitive payment details yourself.

## 8. Recommended build order
1. Publish the front-end.
2. Confirm current syllabus and chapter index for each class.
3. Add a small, quality-checked set of notes per subject.
4. Add original easy/medium/hard question banks and explanations.
5. Add properly sourced/authorized PYQs with year/session metadata.
6. Implement full-length test engine, timer, scoring and review.
7. Deploy secure AI backend and connect tutor.
8. Add student accounts/progress only with appropriate privacy and security.
9. Review premium/payment compliance before enabling payment.
