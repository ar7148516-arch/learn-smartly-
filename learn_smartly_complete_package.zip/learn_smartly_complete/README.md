# Learn Smartly — complete starter package

This is a structured, mobile-friendly starter for a Maharashtra Board + MH-CET + NDA learning website.

## Files
- `index.html` — upload this file to the root of your GitHub Pages repository.
- `data/content-template.json` — subject/chapter/question content structure and sample original practice questions.
- `backend/server-example.js` — optional example backend endpoint for a real AI tutor.
- `backend/package.json` — backend dependencies.
- `CONTENT_AND_LAUNCH_GUIDE.md` — content, PYQ, tests, premium and deployment checklist.

## Publish on GitHub Pages (Android)
1. Extract this ZIP on your phone.
2. Open your GitHub repository.
3. Upload `index.html` to the repository root (same level as README.md).
4. Commit directly to `main`.
5. Settings → Pages → Deploy from a branch → `main` → `/(root)`.
6. Open the Pages URL after deployment finishes.

The ZIP itself is not the website entry point. Upload the extracted `index.html` file.

## Important honest limitations
This package provides the full navigation and page structure, example notes, an original 3-question demo quiz, and a secure-backend integration template. It does NOT contain all official Maharashtra Board chapter notes, ten years of NDA/MH-CET papers, full 120/150-question banks, or a working live AI service. Those require verified syllabus/content sources, permitted question-paper use, and backend deployment. The front-end labels unfilled areas instead of inventing official content.

Do not put an AI API key in `index.html` or any public GitHub file. Set it as a server-side environment variable on a backend host. Payments are only a planned interface; do not collect payments or student personal information until a qualified adult has reviewed provider rules, privacy, refunds and applicable requirements.
